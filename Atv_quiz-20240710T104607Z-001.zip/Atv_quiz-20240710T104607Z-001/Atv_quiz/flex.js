let select1 = document.getElementById("select1")
let select2 = document.getElementById("select2")
let select3 = document.getElementById("select3")

function botao(){
    var select1 = document.getElementById('select1').value
    var select2 = document.getElementById('select2').value
    var select3 = document.getElementById('select3').value
    var resultado = document.getElementById('MostrarResultado')

    var slc = Number(select1) + Number(select2) + Number(select3)


    if (slc <= 1) {
        alert("Você só acertou um")
        resultado.value = slc

    }
    else if (slc <= 2) {
        alert("Você acertou 2!")
        resultado.value = slc

    }
    else if (slc <= 3) {
        alert("VOCÊ ACERTOU TODOS!!!!!")
        resultado.value = slc

    }
    else if(slc <= 0) {
        alert("Você não certou nenhum=(")
        resultado.value = slc

    }
    else{
        alert('algo deu errado.')
    }

}